document.addEventListener('DOMContentLoaded', () => {
    // === Views and Elements ===
    const uploadView = document.getElementById('upload-view');
    const progressView = document.getElementById('progress-view');
    const successView = document.getElementById('success-view');
    const errorView = document.getElementById('error-view');
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const passwordProtectCheckbox = document.getElementById('password-protect');
    const passwordInput = document.getElementById('password-input');
    const oneTimeCheckbox = document.getElementById('onetime-download');
    const expiryTimeSelect = document.getElementById('expiry-time');
    const fileNameProgress = document.getElementById('file-name-progress');
    const fileSizeProgress = document.getElementById('file-size-progress');
    const encryptionStatus = document.getElementById('encryption-status');
    const progressBar = document.getElementById('progress-bar');
    const progressPercentage = document.getElementById('progress-percentage');
    const downloadLinkInput = document.getElementById('download-link');
    const copyButton = document.getElementById('copy-button');
    const copyIcon = document.getElementById('copy-icon');
    const checkIcon = document.getElementById('check-icon');
    const qrCodeContainer = document.getElementById('qr-code');
    const countdownHours = document.getElementById('countdown-hours');
    const countdownMinutes = document.getElementById('countdown-minutes');
    const countdownSeconds = document.getElementById('countdown-seconds');
    const killLinkButton = document.getElementById('kill-link-button');
    const shareAnotherButton = document.getElementById('share-another-button');
    const errorMessage = document.getElementById('error-message');
    const tryAgainButton = document.getElementById('try-again-button');
    let countdownInterval;

    // === Event Listeners ===
    passwordProtectCheckbox.addEventListener('change', () => {
        passwordInput.classList.toggle('hidden', !passwordProtectCheckbox.checked);
        if (passwordProtectCheckbox.checked) passwordInput.focus();
    });
    dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('dragover'); });
    dropZone.addEventListener('dragleave', e => { e.preventDefault(); dropZone.classList.remove('dragover'); });
    dropZone.addEventListener('drop', e => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        if (e.dataTransfer.files.length > 0) handleFile(e.dataTransfer.files[0]);
    });
    fileInput.addEventListener('change', e => {
        if (e.target.files.length > 0) handleFile(e.target.files[0]);
    });
    copyButton.addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(downloadLinkInput.value);
            copyIcon.classList.add('hidden');
            checkIcon.classList.remove('hidden');
            setTimeout(() => {
                copyIcon.classList.remove('hidden');
                checkIcon.classList.add('hidden');
            }, 2000);
        } catch (err) {
            console.error('Fehler beim Kopieren: ', err);
            alert('Konnte den Link nicht kopieren. Bitte manuell kopieren.');
        }
    });
    shareAnotherButton.addEventListener('click', resetApp);
    tryAgainButton.addEventListener('click', resetApp);

    // === Upload- und Verschlüsselungs-Logik ===

    function handleFile(file) {
        if (passwordProtectCheckbox.checked && !passwordInput.value) {
            const modal = document.getElementById('password-warning-modal');
            const setPasswordBtn = document.getElementById('set-password-btn');
            const uploadWithoutPasswordBtn = document.getElementById('upload-without-password-btn');

            modal.classList.remove('hidden');

            setPasswordBtn.onclick = () => {
                modal.classList.add('hidden');
                passwordInput.focus();
            };

            uploadWithoutPasswordBtn.onclick = () => {
                modal.classList.add('hidden');
                passwordProtectCheckbox.checked = false;
                passwordInput.classList.add('hidden');
                proceedWithUpload(file);
            };
            return;
        }
        proceedWithUpload(file);
    }

    const bufferToBase64 = (buffer) => btoa(String.fromCharCode(...new Uint8Array(buffer)));

    async function proceedWithUpload(file) {
        uploadView.classList.add('hidden');
        errorView.classList.add('hidden');
        progressView.classList.remove('hidden');

        fileNameProgress.textContent = file.name;
        fileSizeProgress.textContent = `${(file.size / 1024 / 1024).toFixed(2)} MB`;

        const usePassword = passwordProtectCheckbox.checked && passwordInput.value;

        try {
            encryptionStatus.textContent = 'Lese Datei...';
            const fileBuffer = await file.arrayBuffer();

            encryptionStatus.textContent = 'Generiere Datei-Schlüssel...';
            const { key: fileKey, iv: fileIv } = await generateAesKey();
            
            encryptionStatus.textContent = 'Verschlüssele Datei im Browser...';
            const encryptedFileBuffer = await encryptData(fileBuffer, fileKey, fileIv);
            const encryptedBlob = new Blob([encryptedFileBuffer], { type: 'application/octet-stream' });

            let keyFragment;
            if (usePassword) {
                encryptionStatus.textContent = 'Verschlüssele Schlüssel mit Passwort...';
                const exportedFileKey = await crypto.subtle.exportKey('raw', fileKey);
                const salt = crypto.getRandomValues(new Uint8Array(16));
                const passwordKey = await deriveKeyFromPassword(passwordInput.value, salt);
                const keyIv = crypto.getRandomValues(new Uint8Array(12));
                const encryptedKey = await encryptData(exportedFileKey, passwordKey, keyIv);
                
                keyFragment = `p.${bufferToBase64(salt)}.${bufferToBase64(keyIv)}.${bufferToBase64(encryptedKey)}.${bufferToBase64(fileIv)}`;
            } else {
                encryptionStatus.textContent = 'Bereite sicheren Link vor...';
                const exportedFileKey = await crypto.subtle.exportKey('raw', fileKey);
                keyFragment = `${bufferToBase64(exportedFileKey)}.${bufferToBase64(fileIv)}`;
            }
            
            encryptionStatus.textContent = 'Lade verschlüsselte Daten hoch...';
            
            // Simuliere einen Upload-Fortschritt, da fetch() keinen nativen Fortschritt bietet
            updateProgress(30, 'Lade hoch...');
            const result = await uploadFile(encryptedBlob, file.name, oneTimeCheckbox.checked, expiryTimeSelect.value);
            const finalUrl = `${result.downloadUrl}#${keyFragment}`;
            showSuccessView(finalUrl, result.deleteUrl, result.expiresAt, result.expiryLabel);

        } catch (err) {
            console.error('E2EE process failed:', err);
            showErrorView(err.message || 'Ein unerwarteter Fehler ist aufgetreten.');
        }
    }

    async function generateAesKey() {
        const key = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
        const iv = crypto.getRandomValues(new Uint8Array(12));
        return { key, iv };
    }
    
    async function deriveKeyFromPassword(password, salt) {
        const encoder = new TextEncoder();
        const keyMaterial = await crypto.subtle.importKey('raw', encoder.encode(password), { name: 'PBKDF2' }, false, ['deriveKey']);
        return await crypto.subtle.deriveKey(
            { name: 'PBKDF2', salt: salt, iterations: 100000, hash: 'SHA-256' },
            keyMaterial,
            { name: 'AES-GCM', length: 256 },
            true,
            ['encrypt', 'decrypt']
        );
    }
    
    async function encryptData(data, key, iv) {
        return await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, data);
    }

    // REFACTURED: Verwendung der modernen fetch API
    async function uploadFile(blob, originalFilename, isOneTime, expiryTime) {
        const formData = new FormData();
        formData.append('file', blob, originalFilename);
        formData.append('onetime', isOneTime);
        formData.append('expiry', expiryTime);

        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'upload.php', true);

            xhr.upload.onprogress = (event) => {
                if (event.lengthComputable) {
                    const percentComplete = (event.loaded / event.total) * 100;
                    updateProgress(percentComplete, 'Lade Datei hoch...');
                }
            };

            xhr.onload = () => {
                if (xhr.status >= 200 && xhr.status < 300) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.status === 'success') {
                            resolve(response);
                        } else {
                            reject(new Error(response.message || 'Ein unbekannter Fehler ist aufgetreten.'));
                        }
                    } catch (e) {
                        reject(new Error('Ungültige Server-Antwort.'));
                    }
                } else {
                    try {
                        const errorResponse = JSON.parse(xhr.responseText);
                        reject(new Error(errorResponse.message || `Server-Fehler: ${xhr.statusText}`));
                    } catch (e) {
                        reject(new Error(`Server-Fehler: ${xhr.statusText}`));
                    }
                }
            };

            xhr.onerror = () => {
                reject(new Error('Netzwerkfehler beim Upload.'));
            };

            xhr.send(formData);
        });
    }

    function updateProgress(percent, statusText) {
        progressBar.style.width = `${percent}%`;
        progressPercentage.textContent = `${Math.round(percent)}%`;
        if (statusText) {
            encryptionStatus.textContent = statusText;
        }
    }

    // === Ansichts- und Hilfsfunktionen ===
    function showSuccessView(finalUrl, deleteUrl, expiresAt, expiryLabel) {
        progressView.classList.add('hidden');
        successView.classList.remove('hidden');
        downloadLinkInput.value = finalUrl;
        killLinkButton.href = deleteUrl;
        
        qrCodeContainer.innerHTML = '';
        try {
            const qrImg = document.createElement('img');
            qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(finalUrl)}&bgcolor=ffffff`;
            qrImg.alt = 'QR Code';
            qrImg.onerror = () => qrCodeContainer.innerHTML = '<p class="text-xs text-red-400">QR-Code konnte nicht geladen werden.</p>';
            qrCodeContainer.appendChild(qrImg);
        } catch (e) {
            qrCodeContainer.innerHTML = '<p class="text-xs text-red-400">QR-Code konnte nicht erstellt werden.</p>';
        }
        
        const successMessage = document.getElementById('success-message');
        if(successMessage) {
            successMessage.textContent = `Ihr sicherer E2E-verschlüsselter Link ist ${expiryLabel} gültig:`
        }

        startCountdown(expiresAt);
    }
    function showErrorView(message) {
        progressView.classList.add('hidden');
        errorView.classList.remove('hidden');
        errorMessage.textContent = message;
    }
    function startCountdown(expiresAt) {
        if (countdownInterval) clearInterval(countdownInterval);
        const endTime = new Date(expiresAt).getTime();
        if (isNaN(endTime)) return;

        countdownInterval = setInterval(() => {
            const now = new Date().getTime();
            const distance = endTime - now;
            if (distance < 0) {
                clearInterval(countdownInterval);
                countdownHours.textContent = '00'; countdownMinutes.textContent = '00'; countdownSeconds.textContent = '00';
                return;
            }
            const hours = Math.floor(distance / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            countdownHours.textContent = String(hours).padStart(2, '0');
            countdownMinutes.textContent = String(minutes).padStart(2, '0');
            countdownSeconds.textContent = String(seconds).padStart(2, '0');
        }, 1000);
    }
    function resetApp() {
        if (countdownInterval) clearInterval(countdownInterval);
        uploadView.classList.remove('hidden');
        progressView.classList.add('hidden');
        successView.classList.add('hidden');
        errorView.classList.add('hidden');
        fileInput.value = '';
        passwordInput.value = '';
        passwordProtectCheckbox.checked = false;
        oneTimeCheckbox.checked = false;
        passwordInput.classList.add('hidden');
        updateProgress(0, 'Verschlüssele Datei im Browser...');
    }

    // PWA Installation
    const installContainer = document.getElementById('install-container');
    if (installContainer) {
        let deferredPrompt;
        const installButton = document.getElementById('install-button');

        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            installContainer.classList.remove('hidden');
        });

        installButton.addEventListener('click', async () => {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                const { outcome } = await deferredPrompt.userChoice;
                console.log(`User response to the install prompt: ${outcome}`);
                deferredPrompt = null;
                installContainer.classList.add('hidden');
            }
        });

        // iOS PWA Anleitung
        const isIos = () => /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
        const isInStandaloneMode = () => ('standalone' in window.navigator) && (window.navigator.standalone);

        if (isIos() && !isInStandaloneMode()) {
            const isIosPromptShown = localStorage.getItem('iosInstallPrompt');
            if (!isIosPromptShown) {
                const iosInstallModal = document.getElementById('ios-install-modal');
                const closeIosModal = document.getElementById('close-ios-modal');
                if (iosInstallModal && closeIosModal) {
                    iosInstallModal.classList.remove('hidden');
                    closeIosModal.addEventListener('click', () => {
                        iosInstallModal.classList.add('hidden');
                        localStorage.setItem('iosInstallPrompt', 'true');
                    });
                }
            }
        }
    }
});
